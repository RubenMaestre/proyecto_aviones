import streamlit as st

def display():
    st.title('Aeropuertos')
    # Aquí iría el resto de tu contenido de la página de inicio