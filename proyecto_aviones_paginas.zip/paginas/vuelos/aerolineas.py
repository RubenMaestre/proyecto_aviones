import streamlit as st

def display():
    st.title('Aerolineas')
    # Aquí iría el resto de tu contenido de la página de inicio