import streamlit as st

def display():
    st.title('Información sobre el proyecto')
    # Aquí iría el resto de tu contenido de la página de inicio